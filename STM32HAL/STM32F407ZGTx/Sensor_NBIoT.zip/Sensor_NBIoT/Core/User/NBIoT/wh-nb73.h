//
// Created by Y on 2020/11/12.
//
#ifndef __WH_NB73_H__
#define __WH_NB73_H__

#include "main.h"

uint16_t crc16(unsigned char *q, int len);

#endif
