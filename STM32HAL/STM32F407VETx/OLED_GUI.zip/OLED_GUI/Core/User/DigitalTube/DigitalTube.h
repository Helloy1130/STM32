//
// Created by Y on 2020/10/28.
//

#ifndef FREERTOS_LED_KEY_DIGITALTUBE_H
#define FREERTOS_LED_KEY_DIGITALTUBE_H

#include "main.h"

void Write595(uint8_t sel, uint8_t num, uint8_t bdot);

#endif //FREERTOS_LED_KEY_DIGITALTUBE_H
