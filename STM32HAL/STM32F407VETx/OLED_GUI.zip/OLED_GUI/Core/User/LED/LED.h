//
// Created by Y on 2020/10/28.
//

#ifndef FREERTOS_LED_KEY_LED_H
#define FREERTOS_LED_KEY_LED_H

#include "main.h"

void turnoffLED(void);
void selectLED(uint8_t led_id);

#endif //FREERTOS_LED_KEY_LED_H
